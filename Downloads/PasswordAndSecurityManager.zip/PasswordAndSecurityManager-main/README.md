# PasswordAndSecurityManager
[NOT SOURCE CODE]
This Password Manager helps you store your passwords by encrypting them to files. Nothing goes over the internet, and unless someone hacks your computer, these accounts are completely safe. Everything is encrypted to ensure that the files can't be open and show the accounts.
You can hold multiple users, each with their own accounts.
